package com.mock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockCertApplicationTests {

	@Test
	void contextLoads() {
	}

}
