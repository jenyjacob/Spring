package com.mock.exception;

public class InfyMockException extends Exception {
	
	public InfyMockException(String message) {
		super(message);
	}

}
