package com.mock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockCertApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockCertApplication.class, args);
	}

}
